import tls from 'tls';

export const tls13GatewayConfig: tls.TlsOptions = {
  minVersion: 'TLSv1.3',
  maxVersion: 'TLSv1.3',
  ciphers: 'TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256',
  rejectUnauthorized: true,
};