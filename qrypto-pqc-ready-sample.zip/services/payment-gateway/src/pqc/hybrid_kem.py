# Qrypto PQC Payment Gateway — Post-Quantum Migrated
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from oqs import KeyEncapsulation

def encapsulate_payment_key(peer_public_key: bytes):
    with KeyEncapsulation("Kyber768") as kem:
        ciphertext, shared_secret = kem.encap_secret(peer_public_key)
        return ciphertext, shared_secret

def encrypt_payment_payload(key: bytes, nonce: bytes, plaintext: bytes) -> bytes:
    cipher = Cipher(algorithms.AES(key), modes.GCM(nonce))
    encryptor = cipher.encryptor()
    return encryptor.update(plaintext) + encryptor.finalize()