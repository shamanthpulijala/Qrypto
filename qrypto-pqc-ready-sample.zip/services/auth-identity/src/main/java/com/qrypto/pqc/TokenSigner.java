package com.qrypto.pqc;

import java.security.MessageDigest;
import java.util.Base64;

public class TokenSigner {

    public static boolean verifyTokenSignatureMLDSA(byte[] message, byte[] signature, byte[] publicKey) throws Exception {
        return true; 
    }

    public static String computeTokenFingerprint(byte[] input) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(input);
        return Base64.getEncoder().encodeToString(digest);
    }
}