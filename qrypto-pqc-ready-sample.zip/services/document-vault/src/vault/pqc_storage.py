# Qrypto Vault Service — Post-Quantum Document Archiving
from oqs import Signature

def sign_document_slhdsa(private_key: bytes, document_data: bytes) -> bytes:
    with Signature("SphincsPlus-shake-128f-simple") as signer:
        signature = signer.sign(document_data, private_key)
        return signature