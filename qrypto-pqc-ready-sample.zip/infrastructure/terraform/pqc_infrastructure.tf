resource "aws_acm_certificate" "pqc_cert" {
  domain_name       = "api.qrypto-pqc.internal"
  key_algorithm     = "ML_KEM_768"
  validation_method = "DNS"

  tags = {
    Environment      = "Production"
    QuantumReadiness = "PQC-Compliant"
  }
}