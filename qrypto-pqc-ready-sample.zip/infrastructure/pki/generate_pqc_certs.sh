#!/bin/bash
echo "Generating Root CA Keypair using ML-DSA-65 (FIPS 204)..."
oqs-openssl req -new -newkey mldsa65 -nodes -keyout pqc-root-ca.key -out pqc-root-ca.csr

echo "Issuing Self-Signed Post-Quantum Root Certificate (SHA-384)..."
oqs-openssl x509 -req -in pqc-root-ca.csr -signkey pqc-root-ca.key -out pqc-root-ca.crt -days 3650