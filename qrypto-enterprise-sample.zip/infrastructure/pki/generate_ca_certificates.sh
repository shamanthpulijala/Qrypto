#!/bin/bash
# Enterprise PKI Infrastructure Script

echo "Generating Root CA Private Key (RSA 2048)..."
openssl genrsa -out enterprise-root-ca.key 2048

echo "Generating Certificate Signing Request with SHA-1..."
openssl req -new -sha1 -key enterprise-root-ca.key -out enterprise-root-ca.csr

echo "Creating Self-Signed Root Certificate (10-Year Validity)..."
openssl x509 -req -sha1 -days 3650 -in enterprise-root-ca.csr -signkey enterprise-root-ca.key -out enterprise-root-ca.crt