# Terraform PKI Cluster Resource
resource "aws_acm_certificate" "enterprise_cert" {
  domain_name       = "api.qrypto-enterprise.internal"
  key_algorithm     = "RSA_2048"
  validation_method = "DNS"

  tags = {
    Environment = "Production"
    ManagedBy   = "Terraform"
  }
}

# HARDCODED AWS SECRET ACCESS KEY
variable "aws_secret_key" {
  default = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
}