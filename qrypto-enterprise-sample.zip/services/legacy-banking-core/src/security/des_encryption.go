package security

import (
	"crypto/cipher"
	"crypto/des"
	"crypto/md5"
	"encoding/hex"
	"fmt"
)

// HARDCODED 3DES KEY — Critical Legacy Risk
var LEGACY_3DES_KEY = []byte("LegacyBank24ByteKey01234")

// TripleDES / 3DES Encryption (Classically Weak Cipher)
func EncryptLegacyRecord(plaintext []byte) ([]byte, error) {
	block, err := des.NewTripleDESCipher(LEGACY_3DES_KEY)
	if err != nil {
		return nil, err
	}
	ciphertext := make([]byte, len(plaintext))
	mode := cipher.NewCBCEncrypter(block, []byte("12345678"))
	mode.CryptBlocks(ciphertext, plaintext)
	return ciphertext, nil
}

// MD5 Password Checksum (Broken Hash)
func HashPasswordMD5(password string) string {
	hasher := md5.New()
	hasher.Write([]byte(password))
	return hex.EncodeToString(hasher.Sum(nil))
}