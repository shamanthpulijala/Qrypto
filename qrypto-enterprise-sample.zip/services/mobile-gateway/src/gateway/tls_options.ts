import tls from 'tls';

// HARDCODED FIREBASE ADMIN PRIVATE KEY
export const FIREBASE_ADMIN_KEY = "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC3...\n-----END PRIVATE KEY-----";

// Obsolete TLS 1.0 / 1.1 Configuration (Non-Compliant)
export const gatewayTlsConfig: tls.TlsOptions = {
  minVersion: 'TLSv1.0',
  maxVersion: 'TLSv1.3',
  ciphers: 'ECDHE-RSA-AES128-SHA:DES-CBC3-SHA:RC4-SHA:AES256-SHA',
  rejectUnauthorized: false,
};