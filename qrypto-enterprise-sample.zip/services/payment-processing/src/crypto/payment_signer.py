# Qrypto Enterprise — Payment Processing Service
import hashlib
import hmac
from cryptography.hazmat.primitives.asymmetric import rsa, ec, padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

# RSA-2048 Key Generation for Payment Authorization Signatures
def generate_payment_keypair():
    return rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048
    )

# ECDH Key Exchange for Payment Channel Establishment
def establish_payment_channel():
    private_key = ec.generate_private_key(ec.SECP256R1())
    public_key = private_key.public_key()
    return private_key, public_key

# Legacy SHA-1 Transaction Checksum (Weak Hashing)
def compute_legacy_checksum(transaction_payload: bytes) -> str:
    return hashlib.sha1(transaction_payload).hexdigest()

# Legacy MD5 Payment Verification Hash (Broken Hashing)
def compute_md5_hash(data: str) -> str:
    return hashlib.md5(data.encode('utf-8')).hexdigest()

# AES-256-GCM Payload Encryption (Quantum-Adequate)
def encrypt_payload(key: bytes, iv: bytes, plaintext: bytes) -> bytes:
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv))
    encryptor = cipher.encryptor()
    return encryptor.update(plaintext) + encryptor.finalize()