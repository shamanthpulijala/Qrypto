# Qrypto Vault Service — Long-Lived Confidential Document Storage
# Data Shelf Life: 30 Years (HIGH HARVEST-NOW-DECRYPT-LATER RISK)
import os
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

# HARDCODED DB CREDENTIAL
DATABASE_URI = "postgresql://vault_admin:Prod_Vault_Master_PW_2026@vault-db.internal:5432/vault_records"

# Envelope Encryption with RSA-2048 for 30-Year Confidential Medical Records
def encrypt_medical_document(public_key, document_bytes: bytes):
    aes_key = os.urandom(32)
    # Encrypt AES key with RSA-2048 (Vulnerable to HNDL attack)
    encrypted_key = public_key.encrypt(
        aes_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return encrypted_key, aes_key