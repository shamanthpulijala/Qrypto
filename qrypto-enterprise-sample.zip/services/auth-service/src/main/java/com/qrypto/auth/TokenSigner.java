package com.qrypto.auth;

import java.security.*;
import java.security.spec.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.util.Base64;

public class TokenSigner {

    // HARDCODED SECRET — Security Violation
    private static final String JWT_SECRET_KEY = "SuperSecretQryptoEnterpriseSigningKey2026!";
    private static final String AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE";

    // RSA-4096 Signature Verification
    public static boolean verifyTokenSignature(PublicKey publicKey, byte[] data, byte[] signature) throws Exception {
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initVerify(publicKey);
        sig.update(data);
        return sig.verify(signature);
    }

    // ECDSA Signature Generation (P-384)
    public static byte[] signWithECDSA(PrivateKey privateKey, byte[] message) throws Exception {
        Signature dsa = Signature.getInstance("SHA384withECDSA");
        dsa.initSign(privateKey);
        dsa.update(message);
        return dsa.sign();
    }

    // Legacy SHA-1 Digest (Deprecated)
    public static String computeSHA1Fingerprint(byte[] input) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        byte[] digest = md.digest(input);
        return Base64.getEncoder().encodeToString(digest);
    }
}