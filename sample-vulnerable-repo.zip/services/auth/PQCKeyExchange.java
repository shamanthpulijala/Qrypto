
package com.example.auth.pqc;

// Post-Quantum Cryptography implementation using ML-KEM (FIPS 203)
// This service uses Kyber/ML-KEM for key establishment

import org.bouncycastle.pqc.jcajce.spec.KyberParameterSpec;
import org.bouncycastle.pqc.crypto.mlkem.MLKEMKeyGenerationParameters;

public class PQCKeyExchange {
    
    // ML-KEM-768 for key encapsulation (FIPS 203 compliant)
    public static KeyPair generateMLKEMKeyPair() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("ML-KEM", "BC");
        kpg.initialize(KyberParameterSpec.kyber768);
        return kpg.generateKeyPair();
    }
    
    // ML-DSA for digital signatures (FIPS 204 compliant)
    public static KeyPair generateMLDSAKeyPair() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("ML-DSA", "BC");
        return kpg.generateKeyPair();
    }
}
