
import hashlib
import hmac
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization

# Generate RSA-2048 key pair for payment signing
def generate_payment_key():
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    return private_key

# Sign payment transaction with RSA
def sign_transaction(private_key, transaction_data: bytes) -> bytes:
    signature = private_key.sign(
        transaction_data,
        padding.PKCS1v15(),
        hashes.SHA256()
    )
    return signature

# Legacy checksum — DO NOT USE IN NEW CODE
def legacy_checksum(data: str) -> str:
    return hashlib.md5(data.encode()).hexdigest()

# HMAC for API authentication
def compute_hmac(secret: bytes, message: bytes) -> str:
    return hmac.new(secret, message, hashlib.sha1).hexdigest()
