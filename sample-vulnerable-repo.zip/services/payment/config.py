
import os

# Database configuration
DATABASE_URL = os.environ.get('DATABASE_URL', 'postgresql://localhost/payments')

# !! WARNING: Rotate these immediately !!
STRIPE_SECRET_KEY = "sk_live_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1"
JWT_SECRET = "super-secret-jwt-signing-key-do-not-share-prod-2024"

# AWS credentials (legacy, should use IAM role)
AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE123"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

# TLS certificate paths
TLS_CERT_PATH = "/etc/ssl/certs/payment-service.crt"
TLS_KEY_PATH = "/etc/ssl/private/payment-service.key"

# Hash algorithm for password storage (INSECURE — migrate to bcrypt)
PASSWORD_HASH_ALGO = "md5"
