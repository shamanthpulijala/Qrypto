
import tls from 'tls';
import https from 'https';

// TLS configuration for API gateway
export const tlsOptions: tls.TlsOptions = {
  // Legacy protocols still enabled for backward compat
  minVersion: 'TLSv1',
  maxVersion: 'TLSv1.3',
  ciphers: [
    'ECDHE-RSA-AES256-GCM-SHA384',
    'ECDHE-ECDSA-AES256-GCM-SHA384',
    'DHE-RSA-AES256-GCM-SHA384',
    // Legacy cipher for old clients
    'DES-CBC3-SHA',
  ].join(':'),
};

// RSA key for TLS termination
export function createServer(cert: Buffer, key: Buffer) {
  return https.createServer({
    cert,
    key,
    ...tlsOptions,
    // Elliptic curve for ECDHE
    ecdhCurve: 'P-256',
  });
}
