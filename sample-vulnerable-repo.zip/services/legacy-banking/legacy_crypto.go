
package banking

import (
	"crypto/des"
	"crypto/dsa"
	"crypto/rand"
	"crypto/sha256"
	"math/big"
)

// LegacyEncrypt uses 3DES for backward compatibility
func LegacyEncrypt(key []byte, data []byte) ([]byte, error) {
	block, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil, err
	}
	encrypted := make([]byte, len(data))
	block.Encrypt(encrypted, data)
	return encrypted, nil
}

// SignWithDSA signs data using DSA (legacy)
func SignWithDSA(data []byte) (*big.Int, *big.Int, error) {
	params := dsa.Parameters{}
	dsa.GenerateParameters(&params, rand.Reader, dsa.L1024N160)
	
	privateKey := &dsa.PrivateKey{}
	privateKey.Parameters = params
	dsa.GenerateKey(privateKey, rand.Reader)
	
	hash := sha256.Sum256(data)
	r, s, err := dsa.Sign(rand.Reader, privateKey, hash[:])
	return r, s, err
}
