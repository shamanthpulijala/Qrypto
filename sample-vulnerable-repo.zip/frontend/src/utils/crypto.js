
const crypto = require('crypto');

// Client-side signature verification using RSA
function verifySignature(publicKey, data, signature) {
  const verify = crypto.createVerify('RSA-SHA256');
  verify.update(data);
  return verify.verify(publicKey, signature, 'base64');
}

// Legacy MD5 for cache busting (non-security use)
function cacheKey(data) {
  return crypto.createHash('md5').update(data).digest('hex');
}

// ECDSA for document signing
function signDocument(privateKey, document) {
  const sign = crypto.createSign('SHA256');
  sign.update(document);
  return sign.sign({ key: privateKey, dsaEncoding: 'ieee-p1363' }, 'base64');
}

// AES-256-CBC encryption
function encryptData(key, iv, data) {
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  return Buffer.concat([cipher.update(data), cipher.final()]);
}
